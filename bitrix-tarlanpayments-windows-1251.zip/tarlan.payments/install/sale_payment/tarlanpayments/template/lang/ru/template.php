<?php
$MESS["SALE_HANDLERS_PAY_SYSTEM_TARLANPAYMENTS_DESCRIPTION"] = "Услугу предоставляет платежный сервис <b>&laquo;Tarlan Payments&raquo;</b>.";
$MESS["SALE_HANDLERS_PAY_SYSTEM_TARLANPAYMENTS_SUM"] = "Сумма к оплате по счету: ";
$MESS["SALE_HANDLERS_PAY_SYSTEM_TARLANPAYMENTS_BUTTON_PAID"] = "Оплатить";
$MESS["SALE_HANDLERS_PAY_SYSTEM_TARLANPAYMENTS_REDIRECT_MESS"] = "Вы будете перенаправлены на страницу оплаты";
$MESS["SALE_HANDLERS_PAY_SYSTEM_TARLANPAYMENTS_WARNING_RETURN"] = "<b>Обратите внимание:</b> если вы откажетесь от покупки, для возврата денег вам придется обратиться в магазин.";
