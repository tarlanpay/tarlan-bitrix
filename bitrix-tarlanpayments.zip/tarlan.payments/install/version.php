<?
$arModuleVersion = array(
    "VERSION" => "1.0.0",
    "VERSION_DATE" => "2024-05-15 10:00:00"
);
