<?
define("ADMIN_MODULE_NAME", "tarlan.payments");
?>
