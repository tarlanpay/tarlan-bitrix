<?php
$MESS["SALE_HANDLERS_PAY_SYSTEM_TARLANPAYMENTS_BUTTON_PAID"] = "Proceed to payment";
$MESS["SALE_HANDLERS_PAY_SYSTEM_TARLANPAYMENTS_DESCRIPTION"] = "Service provided by <b>Tarlan Payments</b>.";
$MESS["SALE_HANDLERS_PAY_SYSTEM_TARLANPAYMENTS_REDIRECT_MESS"] = "You will now be redirected to the payment page";
$MESS["SALE_HANDLERS_PAY_SYSTEM_TARLANPAYMENTS_SUM"] = "Invoice amount: ";
$MESS["SALE_HANDLERS_PAY_SYSTEM_TARLANPAYMENTS_WARNING_RETURN"] = "<b>Attention:</b> you will have to contact the seller if you want to return your order.";
